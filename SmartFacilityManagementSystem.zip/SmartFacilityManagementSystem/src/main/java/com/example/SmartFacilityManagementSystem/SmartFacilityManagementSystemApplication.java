package com.example.SmartFacilityManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFacilityManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartFacilityManagementSystemApplication.class, args);
	}

}
