package com.example.SmartFacilityManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFacilityManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
